/*
    MIT License

    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

import { Subjects, sequelize } from "../models/Subjects.js";

await sequelize.sync();

const FIELDS = ["SubjectCode", "CourseTitle", "CourseDescription", "YearLevel", "Units"];

const subjects = {
  // INSERT — POST /subjects
  insert: async (req, res) => {
    try {
      const body = {};
      const missing = [];
      for (const f of FIELDS) {
        if (!req.body[f]) missing.push(f);
        body[f] = req.body[f];
      }
      if (missing.length) {
        return res.status(400).json({ status: "false", message: `Missing fields: ${missing.join(", ")}` });
      }

      const created = await Subjects.create(body);
      res.status(201).json({ status: "true", message: "Subject inserted", data: created });
    } catch (err) {
      console.error("❌ Failed to insert subject:", err);
      res.status(500).json({ status: "false", message: err.message });
    }
  },

  // SELECT ALL — GET /subjects
  all: async (req, res) => {
    try {
      const rows = await Subjects.findAll();
      res.status(200).json({ status: "true", count: rows.length, data: rows });
    } catch (err) {
      console.error("❌ Failed to select subjects:", err);
      res.status(500).json({ status: "false", message: err.message });
    }
  },

  // SELECT BY ID — GET /subjects/:id
  selectById: async (req, res) => {
    try {
      const row = await Subjects.findByPk(req.params.id);
      if (!row) {
        return res.status(404).json({ status: "false", message: `Subject with id ${req.params.id} not found` });
      }
      res.status(200).json({ status: "true", data: row });
    } catch (err) {
      console.error("❌ Failed to find subject:", err);
      res.status(500).json({ status: "false", message: err.message });
    }
  }
};

export { subjects };
