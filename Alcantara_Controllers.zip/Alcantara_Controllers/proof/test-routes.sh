#!/usr/bin/env bash
# =====================================================================
# Alcantara_Controllers — route proof runner
# Tests all 15 routes (5 controllers x [insert, select all, select by id])
# Usage:  bash proof/test-routes.sh [BASE_URL]
# =====================================================================
set -u
BASE="${1:-http://localhost:4000}"
OUT="$(cd "$(dirname "$0")" && pwd)/routes-output.txt"
: > "$OUT"

hit() {
  local n="$1"; local method="$2"; local path="$3"; local data="${4:-}"
  echo "===================================================================" | tee -a "$OUT"
  echo "ROUTE $n  ->  $method $BASE$path" | tee -a "$OUT"
  echo "-------------------------------------------------------------------" | tee -a "$OUT"
  if [ -n "$data" ]; then
    echo "REQUEST BODY:" | tee -a "$OUT"
    echo "$data" | tee -a "$OUT"
    echo "RESPONSE:" | tee -a "$OUT"
    curl -s -w "\n[HTTP %{http_code}]\n" -X "$method" "$BASE$path" \
      -H "Content-Type: application/json" -d "$data" | tee -a "$OUT"
  else
    echo "RESPONSE:" | tee -a "$OUT"
    curl -s -w "\n[HTTP %{http_code}]\n" -X "$method" "$BASE$path" | tee -a "$OUT"
  fi
  echo "" | tee -a "$OUT"
}

echo "### ALcantara_Controllers — 15 ROUTES PROOF ###" | tee -a "$OUT"
echo "Date: $(date)" | tee -a "$OUT"
echo "" | tee -a "$OUT"

# Seed extra rows so SELECT ALL returns multiple records
curl -s -o /dev/null -X POST "$BASE/students" -H "Content-Type: application/json" \
  -d '{"FirstName":"Maria","LastName":"Santos","MiddleName":"Reyes","Program":"BSIT","YearLevel":"3","Section":"A"}'
curl -s -o /dev/null -X POST "$BASE/students" -H "Content-Type: application/json" \
  -d '{"FirstName":"Jose","LastName":"Dela Cruz","MiddleName":"Rizal","Program":"BSCS","YearLevel":"2","Section":"B"}'

# ---- STUDENTS ----
hit 1  POST /students   '{"FirstName":"Juan","LastName":"Alcantara","MiddleName":"Cruz","Program":"BSIT","YearLevel":"4","Section":"A"}'
hit 2  GET  /students
hit 3  GET  /students/1

# ---- SUBJECTS ----
hit 4  POST /subjects   '{"SubjectCode":"IT101","CourseTitle":"Introduction to Computing","CourseDescription":"Fundamentals of computers","YearLevel":"1","Units":"3"}'
hit 5  GET  /subjects
hit 6  GET  /subjects/1

# ---- TEACHERS ----
hit 7  POST /teachers   '{"FirstName":"Anna","LastName":"Lopez","Email":"anna.lopez@minsu.edu.ph","Department":"CCS","ContactNumber":"09171234567"}'
hit 8  GET  /teachers
hit 9  GET  /teachers/1

# ---- COURSES ----
hit 10 POST /courses    '{"CourseCode":"BSIT","CourseName":"BS in Information Technology","Description":"4-year IT program","Units":"180","Department":"CCS"}'
hit 11 GET  /courses
hit 12 GET  /courses/1

# ---- ENROLLMENTS ----
hit 13 POST /enrollments '{"StudentId":"1","SubjectCode":"IT101","Semester":"1st Semester","SchoolYear":"2026-2027","Grade":"1.00"}'
hit 14 GET  /enrollments
hit 15 GET  /enrollments/1

echo "===================================================================" | tee -a "$OUT"
echo "✅ Done. Full output saved to $OUT" | tee -a "$OUT"
