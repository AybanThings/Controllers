/*
  Builds proof/report.html from the captured proof artifacts:
    - proof/routes-output.txt   (15 routes, real request/response)
    - proof/route-list.txt      (registered routes table)
    - proof/database-output.txt (tables + rows)
  Run:  node proof/build-report.js
*/
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const read = (f) => fs.readFileSync(path.join(__dirname, f), "utf8");
const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const routesRaw = read("routes-output.txt");
const routeList = read("route-list.txt");
const dbRaw = read("database-output.txt");
const collection = JSON.parse(read("Alcantara_Controllers.postman_collection.json"));

// Postman collection summary (folders + requests)
const postmanSummary = collection.item
  .map((folder) => {
    const lines = folder.item
      .map((r) => `    ${r.request.method.padEnd(5)} ${r.request.url.raw.replace("{{baseUrl}}", "http://localhost:4000")}`)
      .join("\n");
    return `  📁 ${folder.name}\n${lines}`;
  })
  .join("\n\n");

// Split the routes output into per-route blocks
const blocks = [];
const re = /ROUTE (\d+)\s+->\s+(\w+) (\S+)([\s\S]*?)(?=\nROUTE \d+\s+->|\n=+\n✅ Done|$)/g;
let m;
while ((m = re.exec(routesRaw)) !== null) {
  blocks.push({ n: m[1], method: m[2], url: m[3], body: m[4].trim() });
}

const methodClass = (mm) =>
  mm === "POST" ? "post" : mm === "GET" ? "get" : "other";

const routeCards = blocks
  .map((b) => {
    // response body is the text before the [HTTP ..] marker
    const httpMatch = b.body.match(/\[HTTP (\d+)\]/);
    const status = httpMatch ? httpMatch[1] : "-";
    let payload = b.body.replace(/\[HTTP \d+\]/, "").trim();
    let requestBody = "";
    const reqIdx = payload.indexOf("REQUEST BODY:");
    const resIdx = payload.indexOf("RESPONSE:");
    if (reqIdx !== -1) {
      requestBody = payload.slice(reqIdx + "REQUEST BODY:".length, resIdx).trim();
      payload = payload.slice(resIdx + "RESPONSE:".length).trim();
    }
    const ok = /^2\d\d$/.test(status);
    return `
      <div class="card">
        <div class="card-head">
          <span class="num">#${b.n}</span>
          <span class="method ${methodClass(b.method)}">${b.method}</span>
          <span class="path">${esc(b.url.replace(/^https?:\/\/[^/]+/, ""))}</span>
          <span class="status ${ok ? "ok" : "bad"}">HTTP ${status}</span>
        </div>
        ${requestBody ? `<div class="label">Request body</div><pre class="req">${esc(requestBody)}</pre>` : ""}
        <div class="label">Response</div>
        <pre class="res">${esc(payload)}</pre>
      </div>`;
  })
  .join("\n");

const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Alcantara_Controllers — Proof Report</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: "Segoe UI", Arial, sans-serif; background:#f4f6f8; color:#1f2937; margin:0; padding:32px; }
  .wrap { max-width: 1000px; margin: 0 auto; }
  h1 { margin:0; font-size:30px; }
  .sub { color:#6b7280; margin:6px 0 0; }
  .badges { margin:18px 0 28px; }
  .badge { display:inline-block; background:#111827; color:#fff; border-radius:999px; padding:6px 14px; font-size:13px; margin:0 8px 8px 0; }
  h2 { font-size:20px; border-left:5px solid #ff6a00; padding-left:10px; margin:34px 0 14px; }
  pre { background:#0f172a; color:#e2e8f0; padding:14px 16px; border-radius:8px; overflow:auto; font-size:12.5px; line-height:1.5; white-space:pre-wrap; word-break:break-word; }
  .card { background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:16px; margin-bottom:16px; box-shadow:0 1px 2px rgba(0,0,0,.05); }
  .card-head { display:flex; align-items:center; gap:10px; margin-bottom:10px; }
  .num { color:#9ca3af; font-weight:600; }
  .method { font-weight:700; font-size:12px; padding:3px 10px; border-radius:6px; color:#fff; }
  .method.post { background:#f59e0b; }
  .method.get { background:#2563eb; }
  .path { font-family:Consolas,monospace; font-weight:600; color:#111827; }
  .status { margin-left:auto; font-size:12px; font-weight:700; padding:3px 10px; border-radius:6px; }
  .status.ok { background:#dcfce7; color:#166534; }
  .status.bad { background:#fee2e2; color:#991b1b; }
  .label { font-size:11px; text-transform:uppercase; letter-spacing:.08em; color:#6b7280; margin:8px 0 6px; }
  .footer { margin-top:30px; color:#6b7280; font-size:13px; text-align:center; }
</style>
</head>
<body>
<div class="wrap">
  <h1>Alcantara_Controllers 🔥</h1>
  <p class="sub">XianFire Framework · Mindoro State University · MySQL 8.0.30 · Express + Sequelize</p>
  <div class="badges">
    <span class="badge">5 Models</span>
    <span class="badge">5 Tables</span>
    <span class="badge">5 Controllers</span>
    <span class="badge">15 Routes</span>
    <span class="badge">Each model: insert · select all · select by id</span>
  </div>

  <h2>Registered Routes (15)</h2>
  <pre id="route-list">${esc(routeList.trim())}</pre>

  <h2>Route Proof — request &amp; response</h2>
  <div id="route-cards">
  ${routeCards}
  </div>

  <h2>Postman Collection (15 requests)</h2>
  <pre id="postman-proof">Alcantara_Controllers - XianFire API.postman_collection.json\nBase URL: http://localhost:4000\n\n${esc(postmanSummary)}</pre>

  <h2>Database Proof — tables &amp; rows</h2>
  <pre id="db-proof">${esc(dbRaw.trim())}</pre>

  <div class="footer">Generated from real server responses · proof/report.html</div>
</div>
</body>
</html>`;

fs.writeFileSync(path.join(__dirname, "report.html"), html);
console.log(`✅ report.html written (${blocks.length} route cards)`);
