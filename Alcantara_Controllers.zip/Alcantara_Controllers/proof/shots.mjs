/*
  Captures proof PNG screenshots from proof/report.html (and the live server).
  Run:
    node ~/.codegpt/skills/browser-automation/browser.mjs \
         file:///C:/Users/carli/Alcantara_Controllers/proof/report.html \
         --script proof/shots.mjs
*/
import fs from "fs";
import path from "path";

export default async function run(page, ui) {
  const dir = path.resolve("proof/screenshots");
  fs.mkdirSync(dir, { recursive: true });
  const shot = async (name, locator) => {
    if (locator) await locator.screenshot({ path: path.join(dir, name) });
    else await page.screenshot({ path: path.join(dir, name), fullPage: true });
  };

  const reportUrl = "file:///C:/Users/carli/Alcantara_Controllers/proof/report.html";
  await page.setViewportSize({ width: 1200, height: 1400 });
  await page.goto(reportUrl, { waitUntil: "load" });
  await page.waitForTimeout(300);

  // 0 — full report
  await shot("00-report-full.png");

  // 1 — route list
  await shot("01-route-list.png", page.locator("#route-list"));

  // 2..16 — one screenshot per route card
  const cards = page.locator("#route-cards .card");
  const n = await cards.count();
  for (let i = 0; i < n; i++) {
    const name = "10-route-" + String(i + 1).padStart(2, "0") + ".png";
    await shot(name, cards.nth(i));
  }

  // Postman collection
  await shot("20-postman.png", page.locator("#postman-proof"));

  // Database proof
  await shot("21-database.png", page.locator("#db-proof"));

  // Live server output (welcome page + a JSON endpoint)
  await page.setViewportSize({ width: 1200, height: 900 });
  await page.goto("http://127.0.0.1:4000/", { waitUntil: "load" });
  await page.waitForTimeout(300);
  await shot("30-output-home.png");

  await page.goto("http://127.0.0.1:4000/students", { waitUntil: "load" });
  await page.waitForTimeout(300);
  await shot("31-output-students-json.png");

  return { screenshots: n + 6, dir };
}
