# Alcantara_Controllers 🔥

XianFire Framework project — **5 Models · 5 Tables · 5 Controllers · 15 Routes**.
Each model has 3 functions: **insert**, **select all**, and **select by id**.

---

## 📋 Requirements Met

| Requirement | Status |
|---|---|
| Create 5 models → 5 tables | ✅ students, subjects, teachers, courses, enrollments |
| Minimum 5 columns each | ✅ every table has 5+ data columns |
| Create 5 controllers | ✅ students, subjects, teachers, courses, enrollments |
| 3 functions per model (insert, select all, select by id) | ✅ 15 controller functions |
| Create 15 routes / parameters | ✅ see route table below |
| Proof: routes, output, database, Postman | ✅ in `proof/` (text + PNG screenshots) |
| GitHub repo | ✅ git repository initialized (push to your own GitHub) |

---

## ⚙️ Tech Stack

- **Framework:** XianFire (Express MVC, `.xian` views)
- **Database:** MySQL 8.0 + Sequelize ORM (`mysql2`)
- **Runtime:** Node.js (ES Modules)

---

## 🚀 Setup & Run

```bash
# 1. Install dependencies
npm install

# 2. Make sure MySQL is running on localhost:3306 (user: root, no password)
#    Laragon → Start All,  or  start the MySQL service

# 3. Create the database + all tables
npm run migrate          # (or: node create-db.js && node migrate.js)

# 4. Start the server
npm start                # http://localhost:3000
# or a custom port:
PORT=4000 npm start
```

> **DB credentials** (edit in `models/db.js`): database `Alcantara_Controllers`, user `root`, password `""`, host `localhost`.

---

## 🗄️ The 5 Models / Tables

| # | Model | Table | Columns (data) |
|---|-------|-------|----------------|
| 1 | `Students.js` | `students` | FirstName, LastName, MiddleName, Program, YearLevel, Section |
| 2 | `Subjects.js` | `subjects` | SubjectCode, CourseTitle, CourseDescription, YearLevel, Units |
| 3 | `Teachers.js` | `teachers` | FirstName, LastName, Email, Department, ContactNumber |
| 4 | `Courses.js` | `courses` | CourseCode, CourseName, Description, Units, Department |
| 5 | `Enrollments.js` | `enrollments` | StudentId, SubjectCode, Semester, SchoolYear, Grade |

*(Sequelize also adds an auto `id`, `createdAt`, and `updatedAt`.)*

---

## 🎮 The 5 Controllers (3 functions each)

Each controller file exports an object with `insert`, `all` (select all), and `selectById`.

| Controller | `insert` | `all` | `selectById` |
|---|---|---|---|
| `controllers/students.js` | ✅ | ✅ | ✅ |
| `controllers/subjects.js` | ✅ | ✅ | ✅ |
| `controllers/teachers.js` | ✅ | ✅ | ✅ |
| `controllers/courses.js` | ✅ | ✅ | ✅ |
| `controllers/enrollments.js` | ✅ | ✅ | ✅ |

---

## 🛣️ The 15 Routes

| # | Method | Route | Controller function | Purpose |
|---|--------|-------|---------------------|---------|
| 1 | POST | `/students` | `students.insert` | insert student |
| 2 | GET | `/students` | `students.all` | select all students |
| 3 | GET | `/students/:id` | `students.selectById` | select student by id |
| 4 | POST | `/subjects` | `subjects.insert` | insert subject |
| 5 | GET | `/subjects` | `subjects.all` | select all subjects |
| 6 | GET | `/subjects/:id` | `subjects.selectById` | select subject by id |
| 7 | POST | `/teachers` | `teachers.insert` | insert teacher |
| 8 | GET | `/teachers` | `teachers.all` | select all teachers |
| 9 | GET | `/teachers/:id` | `teachers.selectById` | select teacher by id |
| 10 | POST | `/courses` | `courses.insert` | insert course |
| 11 | GET | `/courses` | `courses.all` | select all courses |
| 12 | GET | `/courses/:id` | `courses.selectById` | select course by id |
| 13 | POST | `/enrollments` | `enrollments.insert` | insert enrollment |
| 14 | GET | `/enrollments` | `enrollments.all` | select all enrollments |
| 15 | GET | `/enrollments/:id` | `enrollments.selectById` | select enrollment by id |

List them from the terminal with:

```bash
npm run route:list
```

---

## 🧪 Proof (`proof/` folder)

| File | What it proves |
|---|---|
| `routes-output.txt` | Real request + response for all **15 routes** (5× HTTP 201, 10× HTTP 200) |
| `route-list.txt` | `xian route:list` output — **Total: 15 route(s)** |
| `database-output.txt` | `SHOW TABLES`, `DESCRIBE`, and `SELECT *` for all 5 tables |
| `Alcantara_Controllers.postman_collection.json` | Importable Postman collection (15 requests) |
| `report.html` | Combined visual proof report |
| `screenshots/` | PNG pictures for submission |
| `test-routes.sh` | Re-runs the 15-route test and regenerates `routes-output.txt` |

### 📸 Screenshots (`proof/screenshots/`)

- `01-route-list.png` — the 15 registered routes
- `10-route-01.png` … `10-route-15.png` — **one picture per route** (request + response)
- `20-postman.png` — Postman collection contents
- `21-database.png` — database tables and rows
- `30-output-home.png` — live home page output
- `31-output-students-json.png` — live JSON output of `GET /students`
- `00-report-full.png` — everything in one image

### How to regenerate the proof

```bash
npm start &                                  # server on :3000 (adjust port in the script)
bash proof/test-routes.sh http://127.0.0.1:3000
node proof/build-report.js
node ~/.codegpt/skills/browser-automation/browser.mjs \
     "file:///C:/Users/carli/Alcantara_Controllers/proof/report.html" \
     --script proof/shots.mjs
```

---

## 📮 Using the Postman Collection

1. Open Postman → **Import** → choose `proof/Alcantara_Controllers.postman_collection.json`.
2. The collection variable `baseUrl` is `http://localhost:4000` (change it to your port).
3. 5 folders (Students, Subjects, Teachers, Courses, Enrollments), 3 requests each = **15 requests**.

---

## 🐙 GitHub

The project is already a git repository with an initial commit. To publish it:

```bash
# create an empty repo on github.com first (no README), then:
git remote add origin https://github.com/<your-username>/Alcantara_Controllers.git
git branch -M main
git push -u origin main
```

Then take a screenshot of your GitHub repo page as the repo proof.

---

## 📁 Project Structure

```
Alcantara_Controllers/
├── index.js                 # app entry (Express + XianFire)
├── migrate.js               # creates DB + all 5 tables
├── create-db.js             # creates the database
├── list-routes.js           # xian route:list
├── routes/index.js          # the 15 routes
├── controllers/             # 5 controllers (insert, all, selectById)
├── models/                  # db.js + 5 models
├── views/                   # .xian templates
├── public/                  # static assets
└── proof/                   # proof of routes, output, database, Postman
```
