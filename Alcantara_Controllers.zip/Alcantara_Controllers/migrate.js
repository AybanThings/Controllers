/*
    MIT License

    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

import { Sequelize } from "sequelize";
import { sequelize } from "./models/db.js";

// Import all 5 models so sequelize.sync() registers every table
import { Students } from "./models/Students.js";
import { Subjects } from "./models/Subjects.js";
import { Teachers } from "./models/Teachers.js";
import { Courses } from "./models/Courses.js";
import { Enrollments } from "./models/Enrollments.js";

const rootSequelize = new Sequelize("mysql://root:@localhost:3306/");

try {
  await rootSequelize.query("CREATE DATABASE IF NOT EXISTS `Alcantara_Controllers`;");
  console.log("✅ Database 'Alcantara_Controllers' created (if it did not exist)");

  await sequelize.authenticate();
  console.log("✅ Connected to MySQL database!");

  await sequelize.sync({ force: true });
  console.log("✅ 5 tables created for all models!");

  console.log("   • students");
  console.log("   • subjects");
  console.log("   • teachers");
  console.log("   • courses");
  console.log("   • enrollments");
} catch (err) {
  console.error("❌ Migration failed:", err);
} finally {
  process.exit();
}
