/*
    MIT License

    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/

import express from "express";

import { students } from "../controllers/students.js";
import { subjects } from "../controllers/subjects.js";
import { teachers } from "../controllers/teachers.js";
import { courses } from "../controllers/courses.js";
import { enrollments } from "../controllers/enrollments.js";

const router = express.Router();

/* ════════════════════════════════════════════════════════════════
   CONTROLLER 1 — Students        (3 routes)
   ════════════════════════════════════════════════════════════════ */
router.post("/students", students.insert);          // 1  INSERT
router.get("/students", students.all);              // 2  SELECT ALL
router.get("/students/:id", students.selectById);   // 3  SELECT BY ID

/* ════════════════════════════════════════════════════════════════
   CONTROLLER 2 — Subjects        (3 routes)
   ════════════════════════════════════════════════════════════════ */
router.post("/subjects", subjects.insert);          // 4
router.get("/subjects", subjects.all);              // 5
router.get("/subjects/:id", subjects.selectById);   // 6

/* ════════════════════════════════════════════════════════════════
   CONTROLLER 3 — Teachers        (3 routes)
   ════════════════════════════════════════════════════════════════ */
router.post("/teachers", teachers.insert);          // 7
router.get("/teachers", teachers.all);              // 8
router.get("/teachers/:id", teachers.selectById);   // 9

/* ════════════════════════════════════════════════════════════════
   CONTROLLER 4 — Courses         (3 routes)
   ════════════════════════════════════════════════════════════════ */
router.post("/courses", courses.insert);            // 10
router.get("/courses", courses.all);                // 11
router.get("/courses/:id", courses.selectById);     // 12

/* ════════════════════════════════════════════════════════════════
   CONTROLLER 5 — Enrollments     (3 routes)
   ════════════════════════════════════════════════════════════════ */
router.post("/enrollments", enrollments.insert);         // 13
router.get("/enrollments", enrollments.all);             // 14
router.get("/enrollments/:id", enrollments.selectById);  // 15

export default router;
